Vertical games need the following parameters to be set in order for the screen and scanline effects to be rotated.

If you have all of your vertical games in one folder you can load your favourite game and shader preset, change these options in the Shader Parameters then save them as a directory preset.

Otherwise you can save them as a game preset each time you play a new vertical game.


HSM_ROTATE_CORE_IMAGE = "1.000000"
HSM_SCANLINE_DIRECTION = "1.000000"